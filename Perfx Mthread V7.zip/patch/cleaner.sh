#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}
#!/sbin/sh
# Cleanner
#!/sbin/sh
rm -rf /data/magisk_backup_*
rm -rf /data/resource-cache/*
rm -rf /data/system/package_cache/*
rm -rf /cache/*
rm -rf /data/dalvik-cache/*
for i in "$(find /data -type f -name '*shader*')"; do
 rm -f $i
done
sleep 10
#cleaning
rm -r /data/dalvik-cache
rm -rf /cache/*.apk
rm -f /cache/*.tmp
rm -f /data/*.log
rm -f /data/*.txt
rm -f /data/anr/*
rm -f /data/backup/pending/*.tmp
rm -f /data/cache/*.*
rm -f /data/data/*.log
rm -f /data/data/*.txt
rm -f /data/log/*.log
rm -f /data/log/*.txt
rm -f /data/local/*.apk
rm -f /data/local/*.log
rm -f /data/local/*.txt
rm -f /data/local/tmp/*
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/wlan_logs
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -f /sdcard/*.log
rm -f /sdcard/*.CHK
rm -f /storage/emulated/0/*.log
rm -f /data/dalvik-cache/*.apk
rm -f /data/dalvik-cache/*.tmp
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/*
rm -rf /sdcard/LOST.DIR
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun
rm -rf /sdcard/.CacheOfEUI
rm -rf /sdcard/.bstats
rm -rf /sdcard/.taobao
rm -rf /sdcard/Backucup
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/wlan_logs
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -f /sdcard/*.CHK
