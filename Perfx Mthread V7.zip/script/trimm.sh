#!/system/bin
#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}

#fstrim
    fstrim -v /data;
    fstrim -v /system;
    fstrim -v /cache;
    fstrim -v /vendor;
    fstrim -v /product;