#!/bin/sh
#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}
  sleep 120
    echo all > /sys/block/zram0/idle
    sleep 90
    echo idle > /sys/block/zram0/writeback
