SKIPUNZIP=1# Defina como true se você *NÃO* deseja que o Magisk monte
# quaisquer arquivos para você. A maioria dos módulos *NÃO* deve
# definir esta bandeira como true.
SKIPMOUNT=false

# Defina como true se você precisa carregar o arquivo system.prop
PROPFILE=true

# Defina como true se você precisa do script post-fs-data
POSTFSDATA=true

# Defina como true se você precisa do script de serviço late_start
LATESTARTSERVICE=false
SET_PERMISSION() {
ui_print "- Setting Permissions"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/script/lyperf.sh 0 0 0755 0700
}
MOD_EXTRACT() {
unzip -o "$ZIPFILE" service.sh -d $MODPATH >&2
unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
}
MOD_PRINT() {

ui_print "- Installing"
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  set_bindir
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

# You can add more functions to assist your custom script code
set_bindir() {
  local bindir=/system/bin
  local xbindir=/system/xbin

  # Check for existence of /system/xbin directory.
  if [ ! -d /sbin/.magisk/mirror$xbindir ]; then
    # Use /system/bin instead of /system/xbin.
    mkdir -p $MODPATH$bindir
    mv $MODPATH$xbindir/sqlite3 $MODPATH$bindir
    rmdir $MODPATH$xbindir
    xbindir=$bindir
 fi

 ui_print "- Installed to $xbindir"
}


set -x
RM_RF
MOD_PRINT
MOD_EXTRACT
SET_PERMISSION
SET_BINDIR
