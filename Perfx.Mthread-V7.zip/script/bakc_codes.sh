#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}
# Modifications and Tw
vendorprop_systemlib64() {
mkdir -p $NVBASE/modules_update/$MODID/system/
mkdir -p $NVBASE/modules_update/$MODID/system/vendor/
mkdir -p $NVBASE/modules_update/$MODID/system/lib64
cp /vendor/build.prop $NVBASE/modules_update/$MODID/system/vendor/
cp /system/lib64/android.frameworks.displayservice@1.0.so $NVBASE/modules_update/$MODID/system/lib64/
sleep 1
sed -i "/offset/d" $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.use_phase_offsets_as_durations=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.late.sf.duration=10500000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.late.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.early.sf.duration=13800000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.early.app.duration=13800000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.earlyGl.sf.duration=13800000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.earlyGl.app.duration=13800000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.frame_rate_multiple_threshold=120" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
$MODDIR/lcyperf.sh > /dev/null
}
sleep 5


mkdir -p $NVBASE/modules_update/$MODID/system/
mkdir -p $NVBASE/modules_update/$MODID/system/vendor/
mkdir -p

# cpu
function boot_wait() {
 while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; 
done ;
}
sleep 1
# hotp
for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done ;
sleep 1

# Unity Task
echo "com.miHoYo., com.activision., com.epicgames., UnityMain, libunity.so, libil2cpp.so" >  /proc/sys/kernel/sched_lib_name
echo "255" >  /proc/sys/kernel/sched_lib_mask_force
sleep 10

#Kernel
echo "5" > /dev/stune/background/schedtune.boost
echo "1" > /dev/stune/background/schedtune.prefer_idle
echo "15" > /dev/stune/foreground/schedtune.boost
echo "1" > /dev/stune/foreground/schedtune.prefer_idle
echo "0" > /dev/stune/foreground/schedtune.prefer_perf
echo "100" > /dev/stune/rt/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.prefer_idle
echo "100" > /dev/stune/top-app/schedtune.boost
echo "1" > /dev/stune/top-app/schedtune.prefer_idle
echo "0" > /dev/stune/top-app/schedtune.prefer_perf
echo "0-7" > /dev/stune/top-app/cpus
echo "0" > /dev/stune/schedtune.boost
echo "1" > /dev/stune/schedtune.prefer_idle
echo "0" > /dev/stune/schedtune.prefer_perf
echo "0-7" > /dev/cpuset/system-background/cpus
echo "0-7" > /dev/cpuset/background/cpus
echo "0-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
echo "0-7" > /dev/cpuset/cpus
echo "0-7" > /dev/cpuset/restricted/cpus

#sched
echo 5 > /proc/sys/kernel/perf_cpu_time_max_percent 
echo 0 > /proc/sys/kernel/sched_tunable_scaling
echo 0 > /proc/sys/kernel/sched_min_task_util_for_boost_colocation
echo 0 > /proc/sys/kernel/sched_little_cluster_coloc_fmin_khz
echo 1 > /proc/sys/kernel/sched_autogroup_enabled
echo 1 > /proc/sys/kernel/sched_child_runs_first 
echo 5000000 > /proc/sys/kernel/sched_migration_cost_ns
echo 6000000 > /proc/sys/kernel/sched_latency_ns
echo "12000000" > /proc/sys/kernel/sched_wakeup_granularity_ns
echo "10000000" > /proc/sys/kernel/sched_min_granularity_ns
echo "1000000" > /proc/sys/kernel/sched_rt_runtime_us
echo 32 > /proc/sys/kernel/sched_nr_migrate 
echo 0 > /proc/sys/kernel/sched_schedstats 
sleep 1
