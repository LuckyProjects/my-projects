#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}
function get_prop() {
  resetprop "$1"
}

function set_prop() {
  resetprop -n "$1" "$2"
}

function read_file(){
  if [[ -f $1 ]]; then
    if [[ ! -r $1 ]]; then
      chmod +r "$1"
    fi
    cat "$1"
  else
    echo "File $1 not found"
  fi
}

function write_file(){
  if [[ -f $1 ]]; then
    if [[ ! -w $1 ]]; then
      chmod +w "$1"
    fi
    echo "$2" >"$1"
  else
    echo "File $1 not found"
  fi
}

function boot_wait() {
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
}

function opt_game_task() {
  for temp_pid in $(pgrep -fl "$1" | awk !/bindfs/ | awk !/pgrep/ | awk '{print $1}'); do
    for temp_tid in $(ls "/proc/$temp_pid/task/"); do
      comm="$(read_file "/proc/$temp_pid/task/$temp_tid/comm")"
      if echo "$comm" | grep -qiE "Jit thread pool|HeapTaskDaemon|FinalizerDaemon|ReferenceQueueD"; then
        taskset -p "0f" "$temp_tid"
      elif echo "$comm" | grep -qiE "UnityPreload|ace_worker|NativeThread|Thread-|UnityMultiRende|AsyncReadManage|UnityChoreograp|Worker Thread|CoreThread"; then
        taskset -p "ff" "$temp_tid"
      elif echo "$comm" | grep -qiE "UnityMain|UnityGfxDeviceW|Apollo-Source|Apollo-File"; then
        taskset -p "f0" "$temp_tid"
      elif echo "$comm" | grep -qiE "GameThread|Thread-|GLThread|RenderThread"; then
        taskset -p "f0" "$temp_tid"
      elif echo "$comm" | grep -qiE "MIHOYO_NETWORK|Audio|tp_schedule|GVoice|FMOD mixer|FMOD stream|ff_read|Jit thread pool|HeapTaskDaemon|FinalizerDaemon|ReferenceQueueD"; then
        taskset -p "0f" "$temp_tid"

      elif echo "$comm" | grep -qiE "NativeThread|SDLThread|RHIThread|TaskGraphNP|MainThread-UE4"; then
        taskset -p "ff" "$temp_tid"
      else
        taskset -p "ff" "$temp_tid"
      fi
    done
  done
}

function after() {
  boot_wait
  moddir=/data/adb/modules
  set_prop univ.game.taskopt unset
  while true; do
    sleep 10
    WinDump=$(dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | grep -o -e com.activision.callofduty.shooter -e com.olzhass.carparking.multyplayer -e com.epicgames.fortnite -e com.miniclip.agar.io -e xyz.aethersx2.android -e com.YoStarEN.Arknights -e com.pubg.newstate -e com.dts.freefireth -e com.dts.freefiremax -e com.ea.gp.fifamobile -e com.miHoYo.GenshinImpact -e com.mobile.legends -e com.rayark.sdorica -e com.garena.game.kgvn -e com.vng.mlbbvn -e com.ea.games.r3_row -e com.sprduck.garena.vn -e com.gameloft.android.ANMP.GloftMVHM -e com.supercell.brawlstars -e com.autumn.skullgirls -e com.proximabeta.nikke -e com.activision.callofduty.shooter -e com.activision.callofduty.warzone -e com.levelinfinite.hotta.gp -e com.pubg.imobile -e com.tencent.ig -e com.kog.grandchaseglobal -e com.firsttouchgames.dls7 -e net.wargaming.wot.blitz -e com.gabama.monopostolite -e com.miHoYo.GenshinImpact -e com.proximabeta.nikke -e com.je.supersus -e com.citra.emu -e com.dolphinemu.dolphinemu -e com.netease.racerna -e com.riotgames.league.wildrift -e skyline.purple -e org.vita3k.emulator -e org.mm.jr -e com.kakaogames.eversoul -e com.mobile.legends -e com.netease.frxyna -e com.smokoko.race -e com.pearlabyss.blackdesertm.gl -e jp.konami.pesam -e com.netease.racerna -e com.criticalforceentertainment.criticalops -e com.garena.game.codm -e com.stove.epic7.google | head -1)
    if [[ $WinDump ]]; then
      if [[ ! -f $moddir/MLT ]] && [[ ! -f $moddir/MLS ]]; then 
        if [[ ! $(get_prop univ.game.taskopt) == "true" ]]; then
          opt_game_task "$WinDump"
          set_prop univ.game.taskopt true
        fi
      fi
    else
      if [[ ! $(get_prop univ.game.taskopt) == "false" ]]; then
        set_prop univ.game.taskopt false
      fi
    fi
    sleep 10
  done
}

if [[ $1 == "after" ]]; then
  if [[ $2 == "debug" ]]; then
    set -x
    after
  else
    after > /dev/null 2>&1 
  fi
fi