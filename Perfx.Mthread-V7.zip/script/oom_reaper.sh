#!/system/bin/sh

oom_reaper_value=1

echo $oom_reaper_value > /proc/sys/vm/oom_reaper
