#yakt©
#!/system/bin/sh
#!/bin/bash
#conf project
MODDIR=${0%/*}
# Variables
SC=/sys/devices/system/cpu/cpu0/cpufreq/schedutil
TP=/dev/stune/top-app/uclamp.max
DV=/dev/stune
CP=/dev/cpuset
ZW=/sys/module/zswap
MC=/sys/module/mmc_core
WT=/proc/sys/vm/watermark_boost_factor
KL=/proc/sys/kernel
VM=/proc/sys/vm
S2=/sys/devices/system/cpu/cpufreq/schedutil
MG=/sys/kernel/mm/lru_gen
PS=$(cat /proc/version)
BT=$(getprop ro.boot.bootdevice)
BL=/dev/blkio
SX=/sys/devices/system/cpu/cpufreq/policy*
CQM="$(cat /sys/devices/system/cpu/cpufreq/policy*/scaling_max_freq)"

#CPU complement
echo "1" > /sys/devices/system/cpu/cpuidle/use_deepest_state
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo Y > /sys/module/workqueue/parameters/power_efficient
echo "1000000" > /dev/cpuctl/cpu.rt_period_us
echo "950000" > /dev/cpuctl/cpu.rt_period_us
echo "0" > /sys/module/lpm_levels/parameters/sleep_disabled
echo 0 > /proc/sys/kernel/sched_walt_rotate_big_tasks

#CPU OPT
echo "0 0 0 0" > /sys/devices/system/cpu/cpu0/core_ctl/busy_down_thres
echo "0 0 0 0" > /sys/devices/system/cpu/cpu0/core_ctl/busy_up_thres
echo 1 > /sys/devices/system/cpu/cpu0/core_ctl/min_cpus
echo 4294967295 > /sys/devices/system/cpu/cpu0/core_ctl/task_thres
echo "0 0 0 0" > /sys/devices/system/cpu/cpu4/core_ctl/busy_down_thres
echo "0 0 0 0" > /sys/devices/system/cpu/cpu4/core_ctl/busy_up_thres
echo 1 > /sys/devices/system/cpu/cpu4/core_ctl/min_cpus
echo 4294967295 > /sys/devices/system/cpu/cpu4/core_ctl/task_thres
echo "0 0 0 0" > /sys/devices/system/cpu/cpu6/core_ctl/busy_down_thres
echo "0 0 0 0" > /sys/devices/system/cpu/cpu6/core_ctl/busy_up_thres
echo 1 > /sys/devices/system/cpu/cpu6/core_ctl/min_cpus
echo 4294967295 > /sys/devices/system/cpu/cpu4/core_ctl/task_thres

if [ -e /sys/devices/platform/soc/$BT/ufstw_lu0/tw_enable ]; then
    echo lz4 > $ZW/parameters/compressor
    echo zsmalloc > $ZW/parameters/zpool
    done
fi
echo 1 > /proc/sys/kernel/sched_autogroup_enabled
echo 5000000 > $KL/sched_migration_cost_ns
echo 6000000 > $KL/sched_latency_ns
echo 20 > $VM/vfs_cache_pressure
echo 20 > $VM/stat_interval
echo 32 > $VM/watermark_scale_factor
    for ta in $CP/*/top-app
    do
        echo max > "$ta/uclamp.max"
        echo 10 > "$ta/uclamp.min"
        echo 1 > "$ta/uclamp.boosted"
        echo 1 > "$ta/uclamp.latency_sensitive"
    done
    for fd in $CP/*/foreground
    do
        echo 50 > "$fd/uclamp.max"
        echo 0 > "$fd/uclamp.min"
        echo 0 > "$fd/uclamp.boosted"
        echo 0 > "$fd/uclamp.latency_sensitive"
    done
    for bd in $CP/*/background
    do
        echo max > "$bd/uclamp.max"
        echo 20 > "$bd/uclamp.min"
        echo 0 > "$bd/uclamp.boosted"
        echo 0 > "$bd/uclamp.latency_sensitive"
    done
    for sb in $CP/*/system-background
    do
        echo 40 > "$sb/uclamp.max"
        echo 0 > "$sb/uclamp.min"
        echo 0 > "$sb/uclamp.boosted"
        echo 0 > "$sb/uclamp.latency_sensitive"
    done
    sysctl -w kernel.sched_util_clamp_min_rt_default=0
    sysctl -w kernel.sched_util_clamp_min=128
fi
sleep 1
if [ -d $BL ]; then
    echo 1000 > $BL/blkio.weight
    echo 200 > $BL/background/blkio.weight
    echo 2000 > $BL/blkio.group_idle
    echo 0 > $BL/background/blkio.group_idle
fi
sleep 1
if [ -e $KL/sched_schedstats ]; then
    echo 0 > $KL/sched_schedstats
fi
echo "0	0 0 0" > $KL/printk
echo off > $KL/printk_devkmsg
for queue in /sys/block/*/queue
do
    echo 0 > "$queue/iostats"
    echo 128 > "$queue/nr_requests"
done
echo 1 > /proc/sys/kernel/sched_autogroup_enabled
if [ -e /sys/devices/platform/soc/$BT/ufstw_lu0/tw_enable ]; then
    echo 1 > /sys/devices/platform/soc/$BT/ufstw_lu0/tw_enable
fi
    if [ -e $KL/sched_schedstats ]; then
    echo 0 > $KL/sched_schedstats
fi
echo "0	0 0 0" > $KL/printk
echo off > $KL/printk_devkmsg
for queue in /sys/block/*/queue
do
    echo 0 > "$queue/iostats"
    echo 128 > "$queue/nr_requests"
done
fi
sleep 1
echo 1 > /sys/block/zram0/reset
echo lz4 > /sys/block/zram0/comp_algorithm
echo 75% > /sys/block/zram0/mem_limit
mkswap /dev/block/zram0
swapon /dev/block/zram0
